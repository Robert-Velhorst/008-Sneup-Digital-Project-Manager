# `airtap` is an [OPEN Open Source Project](http://openopensource.org/)

## What?

Individuals making significant and valuable contributions are given
commit-access to the project to contribute as they see fit. This project
is more like an open wiki than a standard guarded open source project.

## Rules

There are a few basic ground-rules for contributors:

1. **No `--force` pushes** or modifying the Git history unless rebasing or squashing pull requests.
2. **Non-master branches** ought to be used for ongoing work.
3. **External API changes and significant modifications** ought to be subject to an **internal pull-request** to solicit feedback from other contributors.
4. Internal pull-requests to solicit feedback are _encouraged_ for any other non-trivial contribution but left to the discretion of the contributor.
5. Contributors should attempt to adhere to the prevailing code-style.

## Releases

Declaring formal releases remains the prerogative of the project maintainer.

## Changes to this arrangement

This is an experiment and feedback is welcome! This document may also be
subject to pull-requests or changes by contributors where you believe
you have something valuable to add or change.
