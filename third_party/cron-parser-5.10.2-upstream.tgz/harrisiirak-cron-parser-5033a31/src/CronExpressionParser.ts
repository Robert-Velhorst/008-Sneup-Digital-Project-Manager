import { CronFieldCollection } from './CronFieldCollection';
import { CronExpression, CronExpressionOptions } from './CronExpression';
import { type PRNG, seededRandom } from './utils/random';
import {
  CronSecond,
  CronMinute,
  CronHour,
  CronMonth,
  CronDayOfMonth,
  CronDayOfWeek,
  CronConstraints,
  DayOfMonthRange,
  DayOfWeekRange,
  HourRange,
  MonthRange,
  ParseRangeResponse,
  SixtyRange,
} from './fields';

export enum PredefinedExpressions {
  '@yearly' = '0 0 0 1 1 *',
  '@annually' = '0 0 0 1 1 *',
  '@monthly' = '0 0 0 1 * *',
  '@weekly' = '0 0 0 * * 0',
  '@daily' = '0 0 0 * * *',
  '@hourly' = '0 0 * * * *',
  '@minutely' = '0 * * * * *',
  '@secondly' = '* * * * * *',
  '@weekdays' = '0 0 0 * * 1-5',
  '@weekends' = '0 0 0 * * 0,6',
}

export enum CronUnit {
  Second = 'Second',
  Minute = 'Minute',
  Hour = 'Hour',
  DayOfMonth = 'DayOfMonth',
  Month = 'Month',
  DayOfWeek = 'DayOfWeek',
}

// these need to be lowercase for the parser to work
export enum Months {
  jan = 1,
  feb = 2,
  mar = 3,
  apr = 4,
  may = 5,
  jun = 6,
  jul = 7,
  aug = 8,
  sep = 9,
  oct = 10,
  nov = 11,
  dec = 12,
}

// these need to be lowercase for the parser to work
export enum DayOfWeek {
  sun = 0,
  mon = 1,
  tue = 2,
  wed = 3,
  thu = 4,
  fri = 5,
  sat = 6,
}

export type RawCronFields = {
  second: string;
  minute: string;
  hour: string;
  dayOfMonth: string;
  month: string;
  dayOfWeek: string;
};

/**
 * Static class that parses a cron expression and returns a CronExpression object.
 * @static
 * @class CronExpressionParser
 */
/**
 * Upper bound on the number of values a single field may expand to.
 * No field can hold this many distinct values, so exceeding it always means the list repeats values.
 */
const MAX_FIELD_VALUES = 256;

/**
 * Upper bound on the length of a cron expression.
 * Listing every value of every field needs about half of this, so a longer expression is never meaningful.
 */
const MAX_EXPRESSION_LENGTH = 1024;

export class CronExpressionParser {
  /**
   * Parses a cron expression and returns a CronExpression object.
   * @param {string} expression - The cron expression to parse.
   * @param {CronExpressionOptions} [options={}] - The options to use when parsing the expression.
   * @param {boolean} [options.strict=false] - If true, will throw an error if the expression contains both dayOfMonth and dayOfWeek, or a hashed range or step the field cannot satisfy.
   * @param {CronDate} [options.currentDate=new CronDate(undefined, 'UTC')] - The date to use when calculating the next/previous occurrence.
   *
   * @returns {CronExpression} A CronExpression object.
   */
  static parse(expression: string, options: CronExpressionOptions = {}): CronExpression {
    const { strict = false, hashSeed } = options;
    const rand = seededRandom(hashSeed);

    expression = PredefinedExpressions[expression as keyof typeof PredefinedExpressions] || expression;
    const rawFields = CronExpressionParser.#getRawFields(expression, strict);
    if (!(rawFields.dayOfMonth === '*' || rawFields.dayOfWeek === '*' || !strict)) {
      throw new Error('Cannot use both dayOfMonth and dayOfWeek together in strict mode!');
    }

    const second = CronExpressionParser.#parseField(
      CronUnit.Second,
      rawFields.second,
      CronSecond.constraints,
      rand,
      strict,
    ) as SixtyRange[];
    const minute = CronExpressionParser.#parseField(
      CronUnit.Minute,
      rawFields.minute,
      CronMinute.constraints,
      rand,
      strict,
    ) as SixtyRange[];
    const hour = CronExpressionParser.#parseField(
      CronUnit.Hour,
      rawFields.hour,
      CronHour.constraints,
      rand,
      strict,
    ) as HourRange[];
    const month = CronExpressionParser.#parseField(
      CronUnit.Month,
      rawFields.month,
      CronMonth.constraints,
      rand,
      strict,
    ) as MonthRange[];
    const dayOfMonth = CronExpressionParser.#parseField(
      CronUnit.DayOfMonth,
      rawFields.dayOfMonth,
      CronDayOfMonth.constraints,
      rand,
      strict,
    ) as DayOfMonthRange[];
    const { dayOfWeek: _dayOfWeek, nthDayOfWeek } = CronExpressionParser.#parseNthDay(rawFields.dayOfWeek);
    const dayOfWeek = CronExpressionParser.#parseField(
      CronUnit.DayOfWeek,
      _dayOfWeek,
      CronDayOfWeek.constraints,
      rand,
      strict,
    ) as DayOfWeekRange[];

    const fields = new CronFieldCollection({
      second: new CronSecond(second, { rawValue: rawFields.second }),
      minute: new CronMinute(minute, { rawValue: rawFields.minute }),
      hour: new CronHour(hour, { rawValue: rawFields.hour }),
      dayOfMonth: CronDayOfMonth.fromMonth(month, dayOfMonth, { rawValue: rawFields.dayOfMonth }),
      month: new CronMonth(month, { rawValue: rawFields.month }),
      dayOfWeek: new CronDayOfWeek(dayOfWeek, { rawValue: rawFields.dayOfWeek, nthDayOfWeek }),
    });
    return new CronExpression(fields, { ...options, expression });
  }

  /**
   * Get the raw fields from a cron expression.
   * @param {string} expression - The cron expression to parse.
   * @param {boolean} strict - If true, will throw an error if the expression contains both dayOfMonth and dayOfWeek.
   * @private
   * @returns {RawCronFields} The raw fields.
   */
  static #getRawFields(expression: string, strict: boolean): RawCronFields {
    if (strict && !expression.length) {
      throw new Error('Invalid cron expression');
    }
    expression = expression || '0 * * * * *';
    if (expression.length > MAX_EXPRESSION_LENGTH) {
      throw new Error(`Invalid cron expression, too long, expected at most ${MAX_EXPRESSION_LENGTH} characters`);
    }
    const atoms = expression.trim().split(/\s+/);
    if (strict && atoms.length < 6) {
      throw new Error('Invalid cron expression, expected 6 fields');
    }
    if (atoms.length > 6) {
      throw new Error('Invalid cron expression, too many fields');
    }
    const defaults = ['0', '*', '*', '*', '*', '*'];
    if (atoms.length < defaults.length) {
      atoms.unshift(...defaults.slice(0, defaults.length - atoms.length));
    }
    const [second, minute, hour, dayOfMonth, month, dayOfWeek] = atoms;
    return { second, minute, hour, dayOfMonth, month, dayOfWeek };
  }

  /**
   * Parse a field from a cron expression.
   * @param {CronUnit} field - The field to parse.
   * @param {string} value - The value of the field.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @param {PRNG} rand - The random number generator to use.
   * @param {boolean} strict - If true, will throw an error on an unusable hashed range or step.
   * @private
   * @returns {(number | string)[]} The parsed field.
   */
  static #parseField(
    field: CronUnit,
    value: string,
    constraints: CronConstraints,
    rand: PRNG,
    strict: boolean,
  ): (number | string)[] {
    // Replace aliases for month and dayOfWeek
    if (field === CronUnit.Month || field === CronUnit.DayOfWeek) {
      value = value.replace(/[a-z]{3}/gi, (match) => {
        match = match.toLowerCase();
        const replacer = Months[match as keyof typeof Months] || DayOfWeek[match as keyof typeof DayOfWeek];
        if (replacer === undefined) {
          throw new Error(`Validation error, cannot resolve alias "${match}"`);
        }
        return replacer.toString();
      });
    }

    // Check for valid characters
    if (!constraints.validChars.test(value)) {
      throw new Error(`Invalid characters, got value: ${value}`);
    }

    value = this.#parseWildcard(value, constraints);
    value = this.#parseHashed(value, constraints, rand, field, strict);
    return this.#parseSequence(field, value, constraints);
  }

  /**
   * Parse a wildcard from a cron expression.
   * @param {string} value - The value to parse.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @private
   */
  static #parseWildcard(value: string, constraints: CronConstraints): string {
    return value.replace(/[*?]/g, constraints.min + '-' + constraints.max);
  }

  /**
   * Parse a hashed value from a cron expression.
   * @param {string} value - The value to parse.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @param {PRNG} rand - The random number generator to use.
   * @param {CronUnit} field - The field being parsed, used when reporting an unusable range or step.
   * @param {boolean} strict - If true, will throw an error on an unusable hashed range or step.
   * @private
   */
  static #parseHashed(
    value: string,
    constraints: CronConstraints,
    rand: PRNG,
    field: CronUnit,
    strict: boolean,
  ): string {
    const randomValue = rand();
    let count = 0;
    return value.replace(/H(?:\((\d+)-(\d+)\))?(?:\/(\d+))?/g, (_, min, max, step) => {
      // H(range)/step
      if (min && max && step) {
        const minNum = parseInt(min, 10);
        const maxNum = parseInt(max, 10);
        const stepNum = parseInt(step, 10);

        if (stepNum <= 0) {
          throw new Error(`Invalid step: ${stepNum}, must be positive`);
        }

        const range = CronExpressionParser.#hashedRange(minNum, maxNum, constraints, field, strict);
        count += Math.ceil((range.max - range.min + 1) / stepNum);
        CronExpressionParser.#assertMaxFieldValues(field, count);
        return CronExpressionParser.#hashedStep(randomValue, range.min, range.max, stepNum, field, strict);
      }
      // H(range)
      else if (min && max) {
        const minNum = parseInt(min, 10);
        const maxNum = parseInt(max, 10);

        const range = CronExpressionParser.#hashedRange(minNum, maxNum, constraints, field, strict);
        return String(CronExpressionParser.#hashedValue(randomValue, range.min, range.max));
      }
      // H/step
      else if (step) {
        const stepNum = parseInt(step, 10);

        // Validate step
        if (stepNum <= 0) {
          throw new Error(`Invalid step: ${stepNum}, must be positive`);
        }

        count += Math.ceil((constraints.max - constraints.min + 1) / stepNum);
        CronExpressionParser.#assertMaxFieldValues(field, count);
        return CronExpressionParser.#hashedStep(randomValue, constraints.min, constraints.max, stepNum, field, strict);
      }
      // H
      else {
        return String(CronExpressionParser.#hashedValue(randomValue, constraints.min, constraints.max));
      }
    });
  }

  /**
   * Pick a single hashed value within an inclusive range.
   * @param {number} randomValue - The seeded random value in [0, 1).
   * @param {number} min - Lowest value that may be picked.
   * @param {number} max - Highest value that may be picked.
   * @private
   */
  static #hashedValue(randomValue: number, min: number, max: number): number {
    return Math.floor(randomValue * (max - min + 1)) + min;
  }

  /**
   * Name a field the way the expression object does, rather than the Pascal case of CronUnit.
   * @param {CronUnit} field - The field to name.
   * @private
   */
  static #fieldName(field: CronUnit): string {
    return field.charAt(0).toLowerCase() + field.slice(1);
  }

  /**
   * Narrow an explicit hashed range to the values the field can hold, so that values are only
   * ever drawn from the range a step is measured against. In strict mode a bound outside the
   * field constraints is rejected instead of clamped, which keeps the range reported in the
   * error the one that was written.
   * @param {number} min - Lowest value the expression asks for.
   * @param {number} max - Highest value the expression asks for.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @param {CronUnit} field - The field being parsed, used when reporting an unusable range.
   * @param {boolean} strict - If true, will throw an error on a range outside the constraints.
   * @private
   */
  static #hashedRange(
    min: number,
    max: number,
    constraints: CronConstraints,
    field: CronUnit,
    strict: boolean,
  ): { min: number; max: number } {
    if (min > max) {
      throw new Error(`Invalid range: ${min}-${max}, min > max`);
    }
    if (strict && (min < constraints.min || max > constraints.max)) {
      throw new Error(
        `Invalid range: ${min}-${max}, outside the ${constraints.min}-${constraints.max} range of the ${CronExpressionParser.#fieldName(field)} field`,
      );
    }

    const rangeMin = Math.max(min, constraints.min);
    const rangeMax = Math.min(max, constraints.max);
    if (rangeMin > rangeMax) {
      throw new Error(
        `Invalid range: ${min}-${max}, no usable value in the ${CronExpressionParser.#fieldName(field)} field`,
      );
    }

    return { min: rangeMin, max: rangeMax };
  }

  /**
   * Build the hashed values of a stepped range, offset from the start of the step by the seeded
   * jitter. A step wider than the range leaves no step-aligned value inside it, so a single
   * hashed occurrence within the range is used instead of an empty field, or in strict mode the
   * expression is rejected as unsatisfiable.
   * @param {number} randomValue - The seeded random value in [0, 1).
   * @param {number} min - Lowest value the range allows.
   * @param {number} max - Highest value the range allows.
   * @param {number} step - The step between values, already validated as positive.
   * @param {CronUnit} field - The field being parsed, used when reporting an unusable step.
   * @param {boolean} strict - If true, will throw an error on a step wider than its range.
   * @private
   */
  static #hashedStep(
    randomValue: number,
    min: number,
    max: number,
    step: number,
    field: CronUnit,
    strict: boolean,
  ): string {
    if (strict && step > max - min + 1) {
      throw new Error(
        `Invalid step: ${step}, wider than the ${min}-${max} range of the ${CronExpressionParser.#fieldName(field)} field`,
      );
    }

    const offset = Math.floor(randomValue * step);
    const values = [];
    for (let i = Math.floor(min / step) * step + offset; i <= max; i += step) {
      if (i >= min) {
        values.push(i);
      }
    }

    if (values.length === 0) {
      return String(CronExpressionParser.#hashedValue(randomValue, min, max));
    }

    return values.join(',');
  }

  /**
   * Throw once a field has expanded to more than MAX_FIELD_VALUES values.
   * @param {CronUnit} field - The field being parsed.
   * @param {number} count - The number of values collected so far.
   * @private
   */
  static #assertMaxFieldValues(field: CronUnit, count: number): void {
    if (count > MAX_FIELD_VALUES) {
      throw new Error(`Constraint error, too many values in ${field} field, expected at most ${MAX_FIELD_VALUES}`);
    }
  }

  /**
   * Parse a sequence from a cron expression.
   * @param {CronUnit} field - The field to parse.
   * @param {string} val - The sequence to parse.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @private
   */
  static #parseSequence(field: CronUnit, val: string, constraints: CronConstraints): (number | string)[] {
    const stack: (number | string)[] = [];
    function handleResult(result: number | string | (number | string)[], constraints: CronConstraints) {
      if (Array.isArray(result)) {
        stack.push(...result);
      } else {
        if (CronExpressionParser.#isValidConstraintChar(constraints, result)) {
          stack.push(result);
        } else {
          const v = parseInt(result.toString(), 10);
          const isValid = v >= constraints.min && v <= constraints.max;
          if (!isValid) {
            throw new Error(
              `Constraint error, got value ${result} expected range ${constraints.min}-${constraints.max}`,
            );
          }
          stack.push(field === CronUnit.DayOfWeek ? v % 7 : result);
        }
      }
    }

    const atoms = val.split(',');
    for (const atom of atoms) {
      CronExpressionParser.#assertMaxFieldValues(field, stack.length);
      if (!(atom.length > 0)) {
        throw new Error('Invalid list value format');
      }
      handleResult(CronExpressionParser.#parseRepeat(field, atom, constraints), constraints);
    }
    return stack;
  }

  /**
   * Parse repeat from a cron expression.
   * @param {CronUnit} field - The field to parse.
   * @param {string} val - The repeat to parse.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @private
   * @returns {(number | string)[]} The parsed repeat.
   */
  static #parseRepeat(field: CronUnit, val: string, constraints: CronConstraints): ParseRangeResponse {
    const atoms = val.split('/');
    if (atoms.length > 2) {
      throw new Error(`Invalid repeat: ${val}`);
    }
    if (atoms.length === 2) {
      if (!atoms[0].includes('-')) {
        atoms[0] = `${atoms[0]}-${constraints.max}`;
      }
      return CronExpressionParser.#parseRange(field, atoms[0], parseInt(atoms[1], 10), constraints);
    }

    return CronExpressionParser.#parseRange(field, val, 1, constraints);
  }

  /**
   * Validate a cron range.
   * @param {number} min - The minimum value of the range.
   * @param {number} max - The maximum value of the range.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @private
   * @returns {void}
   * @throws {Error} Throws an error if the range is invalid.
   */
  static #validateRange(min: number, max: number, constraints: CronConstraints): void {
    const isValid = !isNaN(min) && !isNaN(max) && min >= constraints.min && max <= constraints.max;
    if (!isValid) {
      throw new Error(`Constraint error, got range ${min}-${max} expected range ${constraints.min}-${constraints.max}`);
    }
    if (min > max) {
      throw new Error(`Invalid range: ${min}-${max}, min(${min}) > max(${max})`);
    }
  }

  /**
   * Validate a cron repeat interval.
   * @param {number} repeatInterval - The repeat interval to validate.
   * @private
   * @returns {void}
   * @throws {Error} Throws an error if the repeat interval is invalid.
   */
  static #validateRepeatInterval(repeatInterval: number): void {
    if (!(!isNaN(repeatInterval) && repeatInterval > 0)) {
      throw new Error(`Constraint error, cannot repeat at every ${repeatInterval} time.`);
    }
  }

  /**
   * Create a range from a cron expression.
   * @param {CronUnit} field - The field to parse.
   * @param {number} min - The minimum value of the range.
   * @param {number} max - The maximum value of the range.
   * @param {number} repeatInterval - The repeat interval of the range.
   * @private
   * @returns {number[]} The created range.
   */
  static #createRange(field: CronUnit, min: number, max: number, repeatInterval: number): number[] {
    const stack: number[] = [];
    if (field === CronUnit.DayOfWeek && max % 7 === 0 && (max - min) % repeatInterval === 0) {
      stack.push(0);
    }
    for (let index = min; index <= max; index += repeatInterval) {
      if (stack.indexOf(index) === -1) {
        stack.push(index);
      }
    }
    return stack;
  }

  /**
   * Parse a range from a cron expression.
   * @param {CronUnit} field - The field to parse.
   * @param {string} val - The range to parse.
   * @param {number} repeatInterval - The repeat interval of the range.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @private
   * @returns {number[] | string[] | number | string} The parsed range.
   */
  static #parseRange(
    field: CronUnit,
    val: string,
    repeatInterval: number,
    constraints: CronConstraints,
  ): ParseRangeResponse {
    const atoms: string[] = val.split('-');
    if (atoms.length <= 1) {
      return isNaN(+val) ? val : +val;
    }
    const [min, max] = atoms.map((num) => parseInt(num, 10));
    this.#validateRange(min, max, constraints);
    this.#validateRepeatInterval(repeatInterval);

    // Create range
    return this.#createRange(field, min, max, repeatInterval);
  }

  /**
   * Parse a cron expression.
   * @param {string} val - The cron expression to parse.
   * @private
   * @returns {string} The parsed cron expression.
   */
  static #parseNthDay(val: string): { dayOfWeek: string; nthDayOfWeek?: number } {
    const atoms = val.split('#');
    if (atoms.length <= 1) {
      return { dayOfWeek: atoms[0] };
    }
    const nthValue = +atoms[atoms.length - 1];
    const matches = val.match(/([,\-/])/);
    if (matches !== null) {
      throw new Error(
        `Constraint error, invalid dayOfWeek \`#\` and \`${matches?.[0]}\` special characters are incompatible`,
      );
    }
    if (!(atoms.length <= 2 && !isNaN(nthValue) && nthValue >= 1 && nthValue <= 5)) {
      throw new Error('Constraint error, invalid dayOfWeek occurrence number (#)');
    }
    return { dayOfWeek: atoms[0], nthDayOfWeek: nthValue };
  }

  /**
   * Checks if a character is valid for a field.
   * @param {CronConstraints} constraints - The constraints for the field.
   * @param {string | number} value - The value to check.
   * @private
   * @returns {boolean} Whether the character is valid for the field.
   */
  static #isValidConstraintChar(constraints: CronConstraints, value: string | number): boolean {
    return constraints.chars.some((char) => value.toString().includes(char));
  }
}
